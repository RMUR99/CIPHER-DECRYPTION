package datastructurproject;

import java.util.Scanner;



public class Duplicate<E> {//start class dup  
//  a beginnging way to start constructing a singly linked list 
    // we start by initilization and making everything equalling to null 
    public Node<E> head = null;
    public Node<E> tail = null;

    // this is a method that allow the additon it was put as void in this case there was no return 
    // Shamayel Sendi 438017259 
    public void add(E data) {//start class add 
        // below there is a node being constucted 
        Node newNode = new Node(data);
        // below we check if the head is empty or not 
        if (head == null)//empty node
        {//start if  
            // if that is tehe case we assign the new values that was null to be the new node constructed 
            head = newNode;
            tail = newNode;
            newNode.next = head;
        }//end if   
        else {//start else  
            // if it is not empty the after tail node will be the new one that was made
            // after declaring it will equal the head 
            tail.next = newNode;
            tail = newNode;
            tail.next = head;
        }  //end else
    }//end class add 

    // Shamayel Sendi 438017259 
    public Boolean checkDuplicate(Node<E> head) {//start class check  
        // boolean values should be assigned first as false
        boolean dublication = false;
        // we assign values of the current node and index and temp (temp is for reversing)
        Node current = head, index = null, temp = null;
        // checks if the head is empty or not 
        if (head == null) {
            System.out.println("List is empty");
        } else {//start else
            do {//start do
                // below there will be the code used to start reversing
                // we assign temp to the current value 
                // we made index be the value after current
                // we check if the index is not equalling the head , if that is true we check if the current is the same as the index which is after current 
                //once it is similar we return true meaning the dublication is there
                temp = current;
                index = current.next;
                while (index != head) {//start while  
                    if (current.data.equals(index.data)) {
                        return true;
                    }
                    index = index.next;
                }//end while 
                
                current = current.next;
            }//end do
            while (current.next != head );
            
        } //end else
        // a return statemnt is needed cause the method type is boolean
        return dublication;
    }  //end class check

    // a method used for displaying the data and there is no return needed 
    public void display() {  //start display
        //the new node is equalling to head
        Node current = head;
        // check if the head is empty if that is the case then print it is empty 
        if (head == null) { //start if 
            System.out.println("List is empty");
        }//end if  
        // if it is not empty 
        else { //start else 
            do { //start do 
                // start by printing the current data with a space between letters
                System.out.print(" " + current.data);
                current = current.next;
            }//end so
            // here it prints the text the same way the user put it and no space is needed 
            while (current != head);
            System.out.println();
        }//end else   
    }//end class display
}//end class
