package datastructurproject;

import java.util.Scanner;


public class SingelLinkedList<E> { //start class

    Node<E> head;

    public void printReverse(Node<E> head) { //start print
        if (head == null) {
            return; //base case
        }
        printReverse(head.next); //call the next element
        System.out.print(head.data + " ");//print the element in the data
    } //end print

    public void addFirst(E new_data) { //start add first
        Node<E> new_node = new Node<E>(new_data); //add node for built the list
        new_node.next = head;
        head = new_node; //add to the first and update the head
    } //end add first

    public void display() {  //start display
        Node<E> current = head;
        if (head == null) {
            System.out.println("List is empty");
        } else {//start else  
            do {//start do  
                System.out.print(" " + current.data);
                current = current.next;
            }//end do
            while (current != null);
            System.out.println();
        }//end else
    }//end display
}//end class   
