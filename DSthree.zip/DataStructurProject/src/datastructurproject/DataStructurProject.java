package datastructurproject;

import java.util.Scanner;

public class DataStructurProject {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Hello Welcome to Our Program\n If you want to Start with Crytograghy Select 1 ,"
                + " \n if you want Check Duplication Select 2 ,"
                + " \nif you want to reverse select 3");
        int Selection = input.nextInt();
        if (Selection == 1) {
            Q1Cryptography chipertxt = new Q1Cryptography();
            System.out.println("if you want to encode text enter 1, if you eant to decode text enter 2 ");
            int choice = input.nextInt();
            if (choice == 1) {
                System.out.println("Enter the text");
                input.nextLine();
                String en = input.nextLine();
                System.out.println("Enter number");
                int index = input.nextInt();
                System.out.println("Encoding text is: " + chipertxt.encoder(en, index));
            }//end inner if
            else if (choice == 2) {
                System.out.println("Enter the text");
                input.nextLine();
                String de = input.nextLine();
                System.out.println("Enter number");
                int index = input.nextInt();
                System.out.println("Decoding text is: " + chipertxt.decoder(de, index));
            }//end else if
        }//end if
        else if (Selection == 2) {
            Duplicate<String> Dup = new Duplicate<>();
            System.out.println("Enter the sentence to check duplication");
            input.nextLine();
            String sentence = input.nextLine();
            String[] a = sentence.split("");
            for (int i = 0; i < a.length; i++) {
                Dup.add(a[i]);
            }
            Dup.display();
            System.out.println(Dup.checkDuplicate(Dup.head));
        }//end else if 
        else if (Selection == 3) {
            SingelLinkedList<String> Sin = new SingelLinkedList<>();
            System.out.println("Enter the sentene that you want to reverse");
            input.nextLine();
            String sentence = input.nextLine();
            String[] array = sentence.split(" ");
            for (int i = 0; i < array.length; i++) {
                Sin.addFirst(array[i]);
            }
            Sin.display();
            Sin.printReverse(Sin.head);
            System.out.println();
        }//end else if
    }//end main
}//end class
