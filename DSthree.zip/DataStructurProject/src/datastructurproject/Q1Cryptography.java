package datastructurproject;
public class Q1Cryptography {
    // first we create 2 array of string to define different cases 
Character  []upper={'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
Character  []lower={'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};


// Taif Ahmed Al-Otaibe 438015749 
//start methode encode based on signature 
String encoder (String alphapet, int index) {
    // create an empty string for the ciphered text cause spaces are considered during the printing process so we need an empty base 
String Ciphertext=" ";
//check the length of the alphabet once this looped condition is true then a character x will store the alphabet
for(int i=0;i<alphapet.length();i++){//start outter for
Character  x= alphapet.charAt(i);
// i created a conditon for the upper case for the new character 
if(Character.isUpperCase(x))
{//start outter if
    // create a looped condition for the upper case part
for(int j=0;j<upper.length;j++){//start inner for
 // the new given value will be given if the new character is within the same range of the upper length which matches the english alphabet = 26
if(x.equals(upper[j]))
    // here the update of the text will happen and it will be decoded by an index more 
Ciphertext=Ciphertext+upper[(j+index)%upper.length];
}//end inner for
}//end outter if
else
{//start else
    // in this we start creaing a conditon for the second case which is the small case 
    // we check if the j is lower than the lower length that matches the alphabet for loops 
for(int j=0;j<lower.length;j++){//start inner for
    // we check the equality of being within the range of alphavet number 
if(x.equals(lower[j]))
    // here the update of the text will happen and it will be decoded by an index more 
Ciphertext=Ciphertext+lower[(j+index)%lower.length];
}//end inner for
}//end else
}//end outter for
// i used the return statemennt due 2 reasons one the type of method 2 is to cipher the text chosen by the user 
return Ciphertext;   
}//end methode encode





// Reema Zaid Almurayshid 439012193
// i started by constructing the method signature   with the parameter  put in the brief 
String decoder (String cipherText, int index){//start method decode
    // i starting by creating an empty string to avoid conflict while printing 
String plainText="";
// i started by creating a loop for the cyphered text so all the letters are visited in this case 
for(int i=0;i<cipherText.length();i++){//start outter for
    // once the loop conditon becomes true then a new character is stored at a specific index that user might put 
Character  x= cipherText.charAt(i);
// i have created an if statements that shows the cases of both capital and small cases 
// check if the character is considered to be an upper case 
if(Character.isUpperCase(x))
{//start outter if
    // then i have a looped conditon that states if the new charachter is below the range of the alphabet (English) 26
for(int j=0;j<upper.length;j++){//start inner for
    // i made a conditon that tells if the new character is considered to be an upper case 
if(x.equals(upper[j])){//start inner if
    // then i see if the the character is an index before 
if((j-index)>=0)
    // then the plain text on the uppser case will be a digit before 
plainText=plainText+upper[(j-index)];
else
    // if the case is different and it is not an index before then i make the uppercase text with the specific length (alphabet length )  chosen an index less 
      // then  i update the value of the plain text by summing then subtrating and index to decode 
plainText=plainText+upper[(j-index+upper.length)];
}//end inner if
}//end inner for
}//end outter if
else
{//start else
    // this else indicated the lower case of the decoding 
    // i start by creating a suitable for loop syntax 
for(int j=0;j<lower.length;j++){//start inner for
    // i check if my charcter is the same the lower case matching the user's input
if(x.equals(lower[j])){//start outer if
    // then i see if the the character is an index before (decoded)
if((j-index)>=0)
plainText=plainText+lower[(j-index)];
else
// if the case is different and it is not an index before then  making the lowercase text with the specific length (alphabet length ) chosen an index less (not decoded yet)
   
    // then  i update the value of the plain text by summing then subtrating and index to decode 
plainText=plainText+lower[(j-index+lower.length)];
}//end outer if
}//end inner for
}//end else
}//end outer for
// i return the plaintext in order for it to be decoded and be a readable text 
return plainText;   
}//end method decode     
}//end class